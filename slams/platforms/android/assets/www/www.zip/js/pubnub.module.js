﻿(function () {
    "use strict";

    angular.module('starter', []);
    //angular.module('starter.menu.chat', []);
})();
