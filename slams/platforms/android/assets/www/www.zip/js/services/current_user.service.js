angular.module('starter')
.value('currentUser', _.random(1000000).toString());