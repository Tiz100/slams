﻿/*azure connection*/
var client = new WindowsAzure.MobileServiceClient('https://booyahslamv2.azurewebsites.net')
