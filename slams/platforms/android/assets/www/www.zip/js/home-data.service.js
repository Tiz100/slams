//(function() {
//	'use strict';

//	angular
//		.module('starter.home')
//		.factory('homeDataService', homeDataService);

//	homeDataService.$inject = [];

//	/* @ngInject */
//	function homeDataService() {
//		return {
//			email: 'skounis@gmail.com',
//			facebookPage: 'https://www.facebook.com/ionicframework'
//		};
//	}
//})();
